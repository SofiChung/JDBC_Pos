import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.*;

public class CreateCustomer extends JFrame implements ActionListener{

	JPanel PosPanel;
	JTextField nname;
	JTextField bbirth;
	JTextField ccontact;
	JButton newcstmer_Button;
	JButton cancel_Button;
	JLabel lname_;
	JLabel lbirth_;
	JLabel lcontact_;
	
	Connection DB;

	public CreateCustomer(Connection inDB) {
		
		DB = inDB;
		setTitle("ȸ�����");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 220, 180);
		//setResizable(false);
		PosPanel = new JPanel();
		PosPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(PosPanel);
		PosPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		lname_ = new JLabel("������      ");
		nname = new JTextField();
		lbirth_ = new JLabel("����(4�ڸ�) ");
		bbirth = new JTextField();
		lcontact_ = new JLabel("����ó    ");
		ccontact = new JTextField();
		newcstmer_Button = new JButton("���Խ�û");
		cancel_Button = new JButton("���");
		

		nname.setColumns(8);
		bbirth.setColumns(7);
		ccontact.setColumns(7);
		
		PosPanel.add(lname_);
		PosPanel.add(nname);
		PosPanel.add(lbirth_);
		PosPanel.add(bbirth);
		PosPanel.add(lcontact_);
		PosPanel.add(ccontact);
		PosPanel.add(newcstmer_Button);
		PosPanel.add(cancel_Button);
		newcstmer_Button.addActionListener(this);		
		cancel_Button.addActionListener(this);
		
	}

	public void actionPerformed(ActionEvent e) {
		Object ttmp = e.getSource();
		if(ttmp==newcstmer_Button){
			String _nname = nname.getText();
			String _bbirth = bbirth.getText();
			String _ccontact = ccontact.getText();
			try {
				Random r = new Random();
				int rtemp = r.nextInt(9999);
				String cde = String.format("%04d",rtemp);
				
				ArrayList alTemp = new ArrayList();				
				
				String sqlStr5 = "SELECT customer_name from customer";
				System.out.println(sqlStr5);
				PreparedStatement stmt5 = DB.prepareStatement(sqlStr5);
				ResultSet rs5 = stmt5.executeQuery();
				for (int i = 0; rs5.next(); i++) {
					alTemp.add(rs5.getString("customer_name"));
				}
				rs5.close();
				stmt5.close();
				System.out.println(_nname);
				
				if(alTemp.contains(_nname)){
					JOptionPane.showMessageDialog(null,"�ߺ��� ȸ��	�̸��Դϴ�.");
				}else{
					String sqlStr = "INSERT INTO customer VALUES('"+_nname+"','"+cde+"','"+_bbirth+"','"+_ccontact+"','Normal',0)";
					System.out.println(sqlStr);
					PreparedStatement stmt;
					stmt = DB.prepareStatement(sqlStr);
					stmt.executeQuery();
					stmt.close();
					super.setVisible(false);
				}
			} catch (SQLException e1) {
				JOptionPane.showMessageDialog(getParent(), "������ �ʹ� ��ϴ�!\n�̸�, �����̳� ����ó�� �ٽ� �� �� Ȯ�����ּ���.");
			}
		} else if(ttmp==cancel_Button){
			dispose();
		}
	}

}
