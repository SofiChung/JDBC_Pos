import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.*;


public class CreateStaff extends JFrame implements ActionListener{

	private JPanel PosPanel;
	private JTextField namefield;
	private JButton newcstmerButton;
	private JButton cancel_Button;
	Connection DB;
	private JComboBox gradecombo;
	private JLabel lname;
	private JLabel lgrade;

	public CreateStaff(Connection inDB) {
		DB = inDB;
		setVisible(true);
		setTitle("�������");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 200, 160);
		setResizable(false);
		PosPanel = new JPanel();
		PosPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		PosPanel.setLayout(null);
		setContentPane(PosPanel);
		
		lname = new JLabel("������");
		lname.setBounds(10, 10, 60, 20);
		PosPanel.add(lname);
		
		namefield = new JTextField();
		namefield.setBounds(90, 10, 80, 20);
		PosPanel.add(namefield);
		namefield.setColumns(7);
		
		lgrade = new JLabel("����");
		lgrade.setBounds(10, 50, 60, 20);
		PosPanel.add(lgrade);
		
		gradecombo = new JComboBox();
		gradecombo.setBounds(90, 50, 80, 20);
		gradecombo.setMaximumRowCount(12);
		gradecombo.setModel(new DefaultComboBoxModel(new String[] {"Staff", "Supervisor"}));
		PosPanel.add(gradecombo);
		gradecombo.addActionListener(this);
		
		newcstmerButton = new JButton("���");
		newcstmerButton.setBounds(20, 80 , 70, 20);
		PosPanel.add(newcstmerButton);
		newcstmerButton.addActionListener(this);
		cancel_Button = new JButton("���");
		cancel_Button.setBounds(100, 80, 70, 20);
		PosPanel.add(cancel_Button);
		cancel_Button.addActionListener(this);
		
		
		
	}

	public void actionPerformed(ActionEvent e) {
		Object tmp1 = e.getSource();
		if(tmp1==newcstmerButton){
			String name__ = namefield.getText();
			int tmp2 = gradecombo.getSelectedIndex();
			String grade1 = null;
			if(tmp2==0) grade1 = "Staff";
			if(tmp2==1) grade1 = "Supervisor";
			try {
				Random r = new Random();
				int t = r.nextInt(9999);
				String code1 = String.format("%04d",t);
				
				ArrayList alTmp = new ArrayList();
				
				String strr = "SELECT staff_name FROM staff";
				PreparedStatement stmtt = DB.prepareStatement(strr);
				ResultSet rs_ = stmtt.executeQuery();
				for(int i=0; rs_.next();i++){
					alTmp.add(rs_.getString("staff_name"));
				}
				rs_.close();
				stmtt.close();
				
				if(alTmp.contains(name__)){
					JOptionPane.showMessageDialog(null, "�ߺ��� ���� �̸��Դϴ�.");
				}
				else{
				String sqlStr = "INSERT INTO staff VALUES('"+name__+"','"+code1+"','"+grade1+"',0)";
				System.out.println(sqlStr);
				PreparedStatement stmt;
				stmt = DB.prepareStatement(sqlStr);
				stmt.executeQuery();
				stmt.close();
				super.setVisible(false);
				}
			} catch (SQLException e1) {
				JOptionPane.showMessageDialog(getParent(), "������ �ʹ� ��ϴ�! ���� �̸��� �ٽ� �� �� Ȯ�����ּ���.");
			}
		} else if(tmp1 == cancel_Button){
			dispose();
		}
	}

}
