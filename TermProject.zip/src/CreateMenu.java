import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.*;


public class CreateMenu extends JFrame implements ActionListener{

	private JPanel PosPanel;
	private JTextField getName;
	private JButton newmenuButton;
	private JButton cancelButton;
	private JLabel lmenu;
	private JTextField getPrice;
	private JLabel lprice;
	
	Connection DB;
	String[] menutmp;
	JButton[] tmpbutton;

	
	public CreateMenu(Connection inDB, String[] menunames, JButton[] menuButton) {
		DB = inDB;
		menutmp = menunames;
		tmpbutton = menuButton;
		setVisible(true);
		setTitle("�޴����");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 190, 140);
		setResizable(false);
		PosPanel = new JPanel();
		PosPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(PosPanel);
		PosPanel.setLayout(null);
		
		lmenu = new JLabel("�޴���");
		lmenu.setBounds(15, 10, 60, 20);
		PosPanel.add(lmenu);		
		
		getName = new JTextField();
		getName.setBounds(80, 10, 80, 20);
		PosPanel.add(getName);
		getName.setColumns(7);
		
		lprice = new JLabel("����");
		lprice.setBounds(15, 40, 60, 20);
		PosPanel.add(lprice);
		
		getPrice = new JTextField();
		getPrice.setBounds(80, 40, 80, 20);
		PosPanel.add(getPrice);
		getPrice.setColumns(8);		
		newmenuButton = new JButton("���");
		newmenuButton.setBounds(20, 70, 60, 20);
		cancelButton = new JButton("���");
		cancelButton.setBounds(90, 70, 60, 20);
		PosPanel.add(newmenuButton);
		PosPanel.add(cancelButton);
		newmenuButton.addActionListener(this);
		cancelButton.addActionListener(this);
				
	}

	public void actionPerformed(ActionEvent e) {
		Object tmp = e.getSource();
		int _price=0;
		
		
		if(getPrice.getText()==null | getPrice.getText().trim().equals("")){
			_price = 0;
		}else{
			 _price = Integer.valueOf(getPrice.getText());
		}
		
		System.out.println(_price);
		String _name = getName.getText();
		if(tmp == newmenuButton){
			
			ArrayList al = new ArrayList();
			
			try {
				String sqlStr7 = "SELECT menu_name from menu";
				System.out.println(sqlStr7);
				PreparedStatement stmt7 = DB.prepareStatement(sqlStr7);
				ResultSet rs7 = stmt7.executeQuery();
				for (int i = 0; rs7.next(); i++) {
					al.add(rs7.getString("menu_name"));
				}
				rs7.close();
				stmt7.close();
				if (al.contains(_name)) {
					JOptionPane.showMessageDialog(null, "�̹� �����ϴ� �޴��Դϴ�. ");
				}
				else{
					try{
						String sqlStr5 = "SELECT count(menu_name) from menu";
						System.out.println(sqlStr5);
						PreparedStatement stmt5 = DB.prepareStatement(sqlStr5);
						ResultSet rs5 = stmt5.executeQuery();
						rs5.next();
						int iTemp = rs5.getInt("sum(menu_name)");
						rs5.close();
						stmt5.close();
						System.out.println(iTemp);
						if(iTemp>=20) JOptionPane.showMessageDialog(null,"�޴��� �ִ� 20���Դϴ�. ");
						} catch (SQLException eee){
							
						}
						
						try {
							String sqlStr = "INSERT INTO menu VALUES('"+getName.getText()+"',"+_price+")";
							System.out.println(sqlStr);
							PreparedStatement stmt;
							stmt = DB.prepareStatement(sqlStr);
							stmt.executeQuery();
							stmt.close();
							updateMenu();
							super.setVisible(false);
						} catch (SQLException e1) {
							JOptionPane.showMessageDialog(getParent(), "�޴����� �ִ���̴� 7�Դϴ�. ");
						}catch (ArrayIndexOutOfBoundsException e2) {
							JOptionPane.showMessageDialog(null, "�޴��� 20���� �ʰ��� �� �����ϴ�.");
						}
				}
			} catch (SQLException eee) {
				JOptionPane.showMessageDialog(getParent(), "������ �ʹ� ��ϴ�! �޴� �̸��� �ٽ� �� �� Ȯ�����ּ���.");
			}

			
		} else if(tmp == cancelButton){
			this.dispose();
		}
	}
	
	private void updateMenu() {
		try {
			String sqlStr5 = "SELECT menu_name from menu";
			PreparedStatement stmt5 = DB.prepareStatement(sqlStr5);
			ResultSet rs5 = stmt5.executeQuery();
			for (int i = 0; rs5.next(); i++) {
				menutmp[i] = rs5.getString("menu_name");
				tmpbutton[i].setText(menutmp[i]);
			}
			rs5.close();
			stmt5.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
