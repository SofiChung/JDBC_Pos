import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;


public class MainPos extends JFrame implements ActionListener{

	////////////////////////////////////////////////////////GUI 
	JPanel PosPanel;
	
	JMenuBar jmb = new JMenuBar();
	
	// ��� �޴��� 
	JMenu selection = new JMenu("Menu");
	JMenuItem select_open = new JMenuItem("Open");
	JMenuItem select_login = new JMenuItem("Log in");
	JFileChooser selectfile = new JFileChooser();

	// ���� ���� 
	JPanel title = new JPanel();
	JLabel titlelabel = new JLabel("�Ĵ� �ֹ�����");
	JPanel contents = new JPanel();
	
	// ���̺� ���
	JPanel tablelist = new JPanel();
	JPanel innertableList = new JPanel();
	JPanel innertable = new JPanel();
	JButton[] tableButton = new JButton[20];
	String[] tables = { "1", "2", "3", "4", "5", "6", "7", "8", "9",
			"10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" };

	// �ֹ�����
	JPanel orderPanel = new JPanel();
	JTextArea orderArea = new JTextArea();
	JPanel ordering = new JPanel();
	JLabel orderer = new JLabel("������");
	JTextField orderer_name = new JTextField();
	JComboBox tablelistCombo = new JComboBox();
	JLabel orderedTable = new JLabel("���̺���");
	JButton order_button = new JButton("�ֹ�");
	JButton cancel_button = new JButton("���");
	JButton pay_button = new JButton("����");
	

	// �޴�
	JPanel menulist = new JPanel();
	JPanel innermenu = new JPanel();
	JButton[] menuButton = new JButton[20];
	String[] menunames = { "", "", "", "", "", "", "", "", "", "", "",
			"", "", "", "", "", "", "", "", "" };
	
	// ���&��ȸ
	JPanel PosControl = new JPanel();
	JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	JPanel tab1 = new JPanel();
	JPanel tab2 = new JPanel();
	JPanel tab3 = new JPanel();
	JPanel tab4 = new JPanel();
	JPanel m_center = new JPanel();
	JPanel m_south = new JPanel();
	JLabel menuname = new JLabel("�޴���");
	JTextField menuEntered = new JTextField();
	JButton newmenu = new JButton("�޴� ���");
	JTextArea menuArea = new JTextArea();
	JButton findmenu = new JButton("��ȸ");
	JPanel s_south = new JPanel();
	JPanel s_center = new JPanel();
	JTextArea staffArea = new JTextArea();
	JLabel staffname = new JLabel("������");
	JTextField staffEntered = new JTextField();
	JButton newstaff = new JButton("�������");
	JButton findstaff = new JButton("��ȸ");
	JPanel c_center = new JPanel();
	JLabel customername = new JLabel("������");
	JTextField customerEntered = new JTextField();
	JButton newcustomer = new JButton("����");
	JButton findcustomer = new JButton("��ȸ");
	JPanel c_south = new JPanel();
	JTextArea customerArea = new JTextArea();
	JPanel sales_center = new JPanel();
	JLabel saleddate = new JLabel("�Ⱓ");
	JPanel sales_south = new JPanel();
	JTextArea salesArea = new JTextArea();
	JComboBox saleddateCombo = new JComboBox();
	
	////////////////////////////////////////////////////////////////GUI
	
	//�α��� ������ 
	boolean isLogin = false;
	boolean isSupervisor = false;
	boolean havefile = false;
	JFrame LoginFrame = new JFrame("��� �α���");
	JButton LoginButton;
	String LoginName;
	String LoginCode;
	String LoginGrade;
	JTextField LoginNameEntered;
	JTextField LoginCodeEntered;	
	
	//DB
	Connection DB;
	FileReader fr = null;
	BufferedReader br = null;
	File f_file;
	
	//�ֹ� ������
	int tableNum;
	String[] menuOrdered = new String[20];
	int[] p_price = new int[20]; // prices ordered  
	Object Actioned; //buttons that are selected 
	

	public MainPos() {
		//POS ���� 
		PosPanel = new JPanel();
		setTitle("�Ĵ� ���� �ý���");
		PosPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		PosPanel.setLayout(new BorderLayout(0, 0));
		setBounds(100, 100, 700, 850);
		setContentPane(PosPanel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setJMenuBar(jmb);		
		jmb.add(selection);
		selection.add(select_open);
		selection.add(select_login);
		select_login.addActionListener(this);
		select_open.addActionListener(this);
		
		PosPanel.add(title, BorderLayout.NORTH);
		titlelabel.setFont(new Font(null, Font.BOLD, 30));		
		title.setBorder(new LineBorder(new Color(0, 0, 0)));
		title.add(titlelabel);
		
		contents.setBorder(new EmptyBorder(5, 5, 5, 5));
		PosPanel.add(contents, BorderLayout.CENTER);
		contents.setLayout(new GridLayout(2, 2, 0, 0));
		
		// ���̺� ��Ȳ 
		contents.add(tablelist);
		tablelist.setLayout(new BorderLayout(0, 0));
		innertableList.setBorder(new EmptyBorder(20, 5, 20, 5));
		tablelist.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"),
				"���̺� ��Ȳ", TitledBorder.LEADING,
				TitledBorder.TOP, null, new Color(0, 0, 0)));
		tablelist.add(innertableList, BorderLayout.CENTER);
		GridLayout gl = new GridLayout(4, 5);
		gl.setVgap(10);
		gl.setHgap(10);
		innertableList.setLayout(gl);
		for (int i = 0; i < tables.length; i++) {
			innertableList.add(tableButton[i] = new JButton(tables[i]));
			tableButton[i].setBackground(Color.white);
			tableButton[i].setEnabled(false);
			tableButton[i].addActionListener(this);
		}
		
		// �ֹ����� 
		contents.add(orderPanel);
		orderPanel.setLayout(new BorderLayout(0, 0));
		orderPanel.setBorder(new TitledBorder(UIManager
				.getBorder("TitledBorder.border"), "�ֹ�����",
				TitledBorder.LEADING, TitledBorder.TOP, null,
				new Color(0, 0, 0)));
		orderPanel.add(innertable, BorderLayout.CENTER);
		innertable.setLayout(new BorderLayout(0, 0));
		innertable.setBorder(new EmptyBorder(5, 5, 5, 5));
		orderer_name.setColumns(5);
		orderArea.setColumns(20);
		innertable.add(orderArea, BorderLayout.WEST);
		innertable.add(ordering, BorderLayout.CENTER);
		ordering.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		ordering.add(orderer);
		ordering.add(orderer_name);
		ordering.add(orderedTable);
		tablelistCombo.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"}));
		ordering.add(tablelistCombo);
		ordering.add(order_button);
		ordering.add(cancel_button);
		ordering.add(pay_button);
		tablelistCombo.addActionListener(this);
		order_button.addActionListener(this);
		pay_button.addActionListener(this);
		cancel_button.addActionListener(this);
		
		// �޴�
		contents.add(menulist);
		menulist.setLayout(new BorderLayout(0, 0));
		menulist.setBorder(new TitledBorder(null, "�޴�",
				TitledBorder.LEADING, TitledBorder.TOP, null, null));
		menulist.add(innermenu, BorderLayout.CENTER);
		innermenu.setBorder(new EmptyBorder(5, 10, 5, 10));
		innermenu.setLayout(new GridLayout(10, 2, 6, 8));		
		for (int i = 0; i < menunames.length; i++) {
			innermenu.add(menuButton[i] = new JButton(menunames[i]));
			menuButton[i].addActionListener(this);
		}		
		
		// ���/��ȸ		
		contents.add(PosControl);
		PosControl.setLayout(new GridLayout(0, 1, 0, 0));
		PosControl.setBorder(new TitledBorder(null, "���/��ȸ", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		PosControl.add(tabbedPane);
		tabbedPane.addTab("����", null, tab1, null);
		customerEntered.setColumns(8);
		c_center.add(customername);
		c_center.add(customerEntered);		
		c_center.add(newcustomer);
		c_center.add(findcustomer);
		newcustomer.addActionListener(this);
		findcustomer.addActionListener(this);
		tab1.setLayout(new BorderLayout(0, 0));
		tab1.add(c_center, BorderLayout.CENTER);

		customerArea.setRows(10);
		customerArea.setColumns(15);	
		c_south.add(customerArea);
		tab1.add(c_south, BorderLayout.SOUTH);
		
		tabbedPane.addTab("����", null, tab2, null);
		saleddateCombo.setModel(new DefaultComboBoxModel(new String[] {"model1", "model2"}));
		sales_center.add(saleddate);
		sales_center.add(saleddateCombo);
		salesArea.setRows(10);
		salesArea.setColumns(15);
		tab2.setLayout(new BorderLayout(0, 0));
		tab2.add(sales_center, BorderLayout.CENTER);
		tab2.add(sales_south, BorderLayout.SOUTH);
		sales_south.add(salesArea);
		
		tabbedPane.addTab("����", null, tab3, null);
		tab3.setLayout(new BorderLayout(0, 0));
		staffEntered.setColumns(8);
		staffArea.setRows(10);
		staffArea.setColumns(15);
		s_center.add(staffname);
		s_center.add(staffEntered);
		s_center.add(newstaff);
		s_center.add(findstaff);
		s_south.add(staffArea);
		newstaff.addActionListener(this);
		findstaff.addActionListener(this);
		tab3.add(s_center, BorderLayout.CENTER);
		tab3.add(s_south, BorderLayout.SOUTH);
		
		tabbedPane.addTab("�޴�", null, tab4, null);
		tab4.setLayout(new BorderLayout(0, 0));
		m_center.add(menuname);
		m_center.add(menuEntered);
		m_center.add(newmenu);
		m_center.add(findmenu);
		newmenu.addActionListener(this);
		findmenu.addActionListener(this);
		menuEntered.setColumns(8);
		menuArea.setRows(10);
		menuArea.setColumns(15);
		m_south.add(menuArea);
		tab4.add(m_center, BorderLayout.CENTER);
		tab4.add(m_south, BorderLayout.SOUTH);
		
		getContentPane().repaint();
		connectDB();
		setting();
		
	}
	
	public void actionPerformed(ActionEvent e) {
		Actioned = e.getSource();
		for( int i = 0; i<19;i++){
			if(Actioned == menuButton[i])
				Select_Menu();
		}
		if (Actioned == select_login) loginMenu();
		if (Actioned == LoginButton) loginButton();
		if (Actioned == select_open) Fileopen();
		if (Actioned == tablelistCombo) getTable();
		if (Actioned == cancel_button) Cancel();
		if (Actioned == order_button) order();
		if (Actioned == pay_button) Paying();
		if (Actioned == newcustomer) CreateCustomer();
		if (Actioned == newstaff) CreateStaff();
		if (Actioned == newmenu) CreateMenu();
		if (Actioned == findcustomer) Find_Customer();
		if (Actioned == findstaff) Find_Staff();
		if (Actioned == findmenu) Find_Menu();
	}
	
	public void loginMenu(){
		LoginFrame = new JFrame();
		LoginFrame.setTitle("��� �α���");
		LoginFrame.setVisible(true);
		LoginFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		LoginFrame.setBounds(100, 100, 250, 120);
		

		JPanel loginpanel = new JPanel();
		
		loginpanel.setLayout(null);
		LoginFrame.getContentPane().add(loginpanel);

		JLabel _loginname = new JLabel("�̸�");
		_loginname.setBounds(15, 10, 60, 20);
		loginpanel.add(_loginname);		
		
		LoginNameEntered = new JTextField();
		LoginNameEntered.setBounds(80, 10, 60, 20);
		loginpanel.add(LoginNameEntered);
		LoginNameEntered.setColumns(9);
		
		JLabel _logincode = new JLabel("�����ȣ");
		_logincode.setBounds(15, 40, 60, 20);
		loginpanel.add(_logincode);
		
		LoginCodeEntered = new JTextField();
		LoginCodeEntered.setBounds(80, 40, 60, 20);
		loginpanel.add(LoginCodeEntered);
		LoginCodeEntered.setColumns(7);

		LoginButton = new JButton("�α���");
		LoginButton.setBounds(150, 20, 73 , 30);
		loginpanel.add(LoginButton);
		LoginButton.addActionListener(this);
	}
	
	public void loginButton(){
		LoginName = LoginNameEntered.getText();
		LoginCode = LoginCodeEntered.getText();
		LoginGrade = null;

		try {
			String sqlStr = "Select staff_grade from staff where staff_name='"
					+ LoginName + "' and staff_code='" + LoginCode + "'";
			System.out.println(sqlStr);
			PreparedStatement stmt = DB.prepareStatement(sqlStr);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			LoginGrade = rs.getString("staff_grade");
			rs.close();
			stmt.close();

			if (LoginGrade.equals("Supervisor")) {
				isLogin = true;
				isSupervisor = true;
			} else if (LoginGrade.equals("Staff")) {
				isLogin = true;
				isSupervisor = false;
			} else {
				isLogin = false;
				isSupervisor = false;
				JOptionPane.showMessageDialog(getParent(),
						"���̵� Ȥ�� ��й�ȣ�� �߸��Ǿ����ϴ�.");
			}

		} catch (SQLException e1) {
			JOptionPane.showMessageDialog(getParent(),
					"���̵� Ȥ�� ��й�ȣ�� �߸��Ǿ����ϴ�.");
		}

		LoginFrame.setVisible(false);
		setting();
	}
	
	public void getTable(){
		tableNum = tablelistCombo.getSelectedIndex();
		System.out.println(tableNum);
		if(menuOrdered[tableNum] == null)
			orderArea.setText("");
		else                                               
			orderArea.setText(menuOrdered[tableNum] + "\n\n---------------------\n �հ�: \t" + p_price[tableNum]);
	}
	
	
	public void Fileopen(){
		int iTemp = selectfile.showOpenDialog(PosPanel);
		if (iTemp == JFileChooser.APPROVE_OPTION) {
			f_file = this.selectfile.getSelectedFile();
			System.out.println(f_file.getAbsolutePath());
		}

		try {CreateTable();}
		catch (SQLException e100){
			System.out.println(e100);
		}	

		try {
			fr = new FileReader(f_file.getAbsolutePath());
			br = new BufferedReader(fr);
			Scanner s = new Scanner(br);
			String tmpline = s.nextLine();
			while (true) addSchema(tmpline,s);	
		} catch (Exception e2) {
		}
	}

	
	public void Cancel(){
		System.out.println("��ҹ�ư, ���̺� ��ȣ"+tableNum);
		Color c = tableButton[tableNum].getBackground();
		if (c == Color.yellow) {
			menuOrdered[tableNum] = null;
			p_price[tableNum] = 0;
			orderArea.setText("");
			tableButton[tableNum].setBackground(Color.white);
		} else
			JOptionPane.showMessageDialog(getParent(), "�ϴ� �ֹ��� ���� ���ּ���.^^");
	}
	
	public void order(){
		if ((0 <= tableNum && tableNum <= 19)) {
			if (menuOrdered[tableNum] == null) {
			} else {
				tableButton[tableNum].setBackground(Color.yellow);
				tableButton[tableNum].repaint();
			}
		} else
			JOptionPane.showMessageDialog(getParent(), "���̺� ��ȣ�� ���� �������ּ���.");
	}
	
	public void Select_Menu(){
		String tmpmenu ="";
		String tmpprice = "";
		
		if ((0 <= tableNum && tableNum <= 19)) {
			for (int i = 0; i < 20; i++) {
				if (Actioned == menuButton[i])
					tmpmenu = menuButton[i].getText();
			}
			System.out.println(tmpmenu);
			if (tmpmenu.equals("")) {
				JOptionPane.showMessageDialog(null, "�˻���� ����");
			} else {
				int i_tmp = 0;
				try {
					String sqlStr = "SELECT price FROM menu WHERE menu_name='" + tmpmenu + "'";
					PreparedStatement stmt = DB.prepareStatement(sqlStr);
					ResultSet rs = stmt.executeQuery();
					rs.next();
					tmpprice = rs.getString("price");
					rs.close();
					stmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				i_tmp = Integer.valueOf(tmpprice);

				p_price[tableNum] += i_tmp;
				if (menuOrdered[tableNum] == null) {
					menuOrdered[tableNum] = tmpmenu + "\t" + i_tmp;
				} else {
					menuOrdered[tableNum] = menuOrdered[tableNum] + "\n"
							+ tmpmenu + "\t" + i_tmp;
				}
				orderArea.setText(menuOrdered[tableNum]
						+ "\n\n--------------------------------\n �հ� :\t"
						+ p_price[tableNum]);
			}
		} else
			JOptionPane.showMessageDialog(getParent(), "���̺� ��ȣ�� ���� �������ּ���.");

	}
	


	public void CreateCustomer() {
		new CreateCustomer(DB);
	}

	public void CreateStaff() {
		new CreateStaff(DB);
	}

	public void CreateMenu() {
		new CreateMenu(DB,menunames,menuButton);
	}
	
	public void Find_Customer(){
		String tmpname = customerEntered.getText();
		System.out.println(tmpname);
		String tmpcode = null;
		String tmpbirth = null;
		String tmpgrade = null;
		String tmpcontact = null;
		String tmpbreak = null;
		if(!tmpname.equals("")){
			try {
				String sqlStr = "SELECT * FROM customer WHERE customer_name='" + tmpname + "'";
				System.out.println(sqlStr);
				PreparedStatement stmt = DB.prepareStatement(sqlStr);
				ResultSet rs = stmt.executeQuery();
				rs.next();
				tmpname = rs.getString("customer_name");
				tmpcode = rs.getString("customer_code");
				tmpbirth = rs.getString("birthday");
				tmpcontact = rs.getString("contact");
				tmpgrade = rs.getString("grade");
				tmpbreak = rs.getString("breakdown");
				rs.close();
				stmt.close();
				String result;
				result = "������:\t"+tmpname+"\n����ID:\t"+tmpcode+"\n��  ��:\t"+tmpbirth+"\n��ȭ��ȣ: \t"+tmpcontact+"\n�������:\t"+tmpgrade+"\n�� ���űݾ�:\t"+tmpbreak+"��";
				customerArea.setText(result);
			} catch (SQLException e) {
				JOptionPane.showMessageDialog(getParent(), "�˻� ��� ����");
			}				
		}else{
			JOptionPane.showMessageDialog(getParent(), "�̸��� ���� �Է����ּ���.");
		}
	}
	
	public void Find_Staff(){
		try {
			String tmpname = staffEntered.getText();
			String tmpgrade = null;
			int tmpsales;
			if(!tmpname.equals("")){
				try {
					String sqlStr = "SELECT * FROM staff WHERE staff_name='" + tmpname + "'";
					PreparedStatement stmt = DB.prepareStatement(sqlStr);
					ResultSet rs = stmt.executeQuery();
					rs.next();
					tmpname = rs.getString("staff_name");
					System.out.println(tmpname);
					tmpgrade = rs.getString("staff_grade");
					System.out.println(tmpgrade);
					tmpsales = rs.getInt("sales");
					System.out.println(tmpsales);
					rs.close();
					stmt.close();
					
					String result = "������:\t"+tmpname+"\n����:\t"+tmpgrade+"\n�ѽ���:\t"+tmpsales;
					//System.out.println(result);
					staffArea.setText(result);
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(getParent(), "�˻� ��� ����");
				}
			}else{
				JOptionPane.showMessageDialog(getParent(), "�̸��� ���� �Է����ּ���.");
			}
		} catch (Exception e) {
		}				
	}
	
	public void Find_Menu(){
		try {
			String tmpname = menuEntered.getText();
			int i_tmp;
			if(!tmpname.equals("")){
				try {
					String sqlStr = "SELECT distinct * FROM menu WHERE menu_name='" + tmpname + "'";
					PreparedStatement stmt = DB.prepareStatement(sqlStr);
					ResultSet rs = stmt.executeQuery();
					rs.next();
					tmpname = rs.getString("menu_name");
					i_tmp = rs.getInt("price"); 
					rs.close();
					stmt.close();

					String result = "�޴���:\t" + tmpname + "\n����:\t" + i_tmp;
					menuArea.setText(result);
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(getParent(), "�˻� ��� ����");
				}				
			}else{
				JOptionPane.showMessageDialog(getParent(), "�޴� �̸��� ���� �Է����ּ���.");
			}
		} catch (Exception e) {
		}				
	}
	
	public void Paying(){
		Color c = tableButton[tableNum].getBackground();
		String temp = orderer_name.getText();
		System.out.println(tableNum);
		if (c == Color.yellow) {
			tableButton[tableNum].setBackground(Color.white);
			if (!(temp.equals(""))) {
				System.out.println("!!");
				String tmpgrade = null;
				String tmpprice = null;
				try {
					String sqlStr = "SELECT * FROM customer WHERE customer_name='" + temp + "'";
					PreparedStatement stmt = DB.prepareStatement(sqlStr);
					ResultSet rs = stmt.executeQuery();
					while (rs.next()) {
						tmpgrade = rs.getString("grade");
						tmpprice = rs.getString("breakdown");
					}
					rs.close();
					stmt.close();

					int _price = Integer.valueOf(tmpprice);

					System.out.println(tmpgrade);
					if (tmpgrade.equals("Gold")) p_price[tableNum] = p_price[tableNum] * 7 / 10;
					else if (tmpgrade.equals("Silver")) p_price[tableNum] = p_price[tableNum] * 8 / 10;
					else if (tmpgrade.equals("Bronze")) p_price[tableNum] = p_price[tableNum] * 9 / 10;
					else p_price[tableNum] = p_price[tableNum];
					
					_price = p_price[tableNum] + _price;
					String sqlStr2 = "UPDATE customer SET breakdown=" + _price + " WHERE customer_name='" + temp + "'";
					UpdateGrade(_price,temp);
					PreparedStatement stmt2 = DB.prepareStatement(sqlStr2);
					stmt2.executeUpdate();
					stmt2.close();

				} catch (SQLException e1) {
					System.out.println(e1);
				} catch (java.lang.NumberFormatException e2) {
					JOptionPane.showMessageDialog(getParent(), "�������� �ʴ� ȸ���Դϴ�.\n��ȸ������ �����մϴ�.");

					int _price = p_price[tableNum];
					String sqlStr2 = "UPDATE customer SET breakdown=" + _price + " WHERE customer_name='��ȸ��'";
					System.out.println(sqlStr2);
					PreparedStatement stmt2;
					try {
						stmt2 = DB.prepareStatement(sqlStr2);
						stmt2.executeUpdate();
						stmt2.close();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}

				try {
					String sqlStr3 = "INSERT INTO sales VALUES(SYSDATE," + p_price[tableNum] + ")";
					System.out.println(sqlStr3);
					PreparedStatement stmt3;
					stmt3 = DB.prepareStatement(sqlStr3);
					stmt3.executeQuery();
					stmt3.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(getParent(), "ȸ�� �̸��� �Է����� �ʾ� ��ȸ������ �����մϴ�.");
				int _price = p_price[tableNum];
				String sqlStr2 = "UPDATE customer SET breakdown=" + _price + " WHERE customer_name='��ȸ��'";
				System.out.println(sqlStr2);
				PreparedStatement stmt2;
				try {
					stmt2 = DB.prepareStatement(sqlStr2);
					stmt2.executeUpdate();
					stmt2.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

			menuOrdered[tableNum] = null;
			p_price[tableNum] = 0;
			orderArea.setText("");

		} else {
			JOptionPane.showMessageDialog(getParent(),
					"�ֹ��� �Ϸ� �� ���̺��� ��� �����մϴ�\n\"�ֹ��� ���� ���ּ���.\"");
		}
	}
	
	
	public void addSchema(String tmpline, Scanner s) throws SQLException{
		if (tmpline.equals("6")) {			
			for (tmpline = s.nextLine(); tmpline.equals("6") == false; tmpline = s.nextLine()) {
				Random r = new Random();
				int tmp_ = r.nextInt(9999);
				String code = String.format("%04d",tmp_);

				String[] tmpdata = tmpline.split("\t");
				String _name = tmpdata[0];
				String _birth = tmpdata[1];
				String _contact = tmpdata[2];
				String tmpgrade = tmpdata[3];
				int grd_value = 0;
				if (tmpgrade.equals("Gold"))	grd_value = 1000000;
				else if (tmpgrade.equals("Silver")) grd_value = 500000;
				else if (tmpgrade.equals("Bronze")) grd_value = 300000;
				else if (tmpgrade.equals("Normal")) grd_value = 0;
				String sqlStr = "INSERT INTO customer VALUES ('"+ _name + "','"+code+"','" + _birth + "'," + _contact
						+ ",'" + tmpgrade + "'," + grd_value + ")";
				PreparedStatement stmt = DB.prepareStatement(sqlStr);
				ResultSet rs = stmt.executeQuery();
				rs.close();
				stmt.close();
			}
			for (tmpline = s.nextLine(); tmpline.equals("10") == false; tmpline = s.nextLine()) {
				String[] tmpdata = tmpline.split("\t");
				String _name = tmpdata[0];
				Random r = new Random();
				int tmp_ = r.nextInt(9999);
				String tmpcode = String.format("%04d", tmp_);
				String _grade = tmpdata[1];
				String sqlStr2 = "INSERT INTO staff VALUES ('" + _name + "','" + tmpcode + "','" + _grade + "',0)";
				PreparedStatement stmt2 = DB.prepareStatement(sqlStr2);
				ResultSet rs2 = stmt2.executeQuery();
				rs2.close();
				stmt2.close();
			}
			for (tmpline = s.nextLine(); true; tmpline = s.nextLine()) {
				String[] tmpdata = tmpline.split("\t");
				String menu_ = tmpdata[0];
				String price_ = tmpdata[1];
				int _price = Integer.valueOf(price_);
				String sqlStr3 = "INSERT INTO menu VALUES('"
						+ menu_ + "'," + _price + ")";
				PreparedStatement stmt3 = DB.prepareStatement(sqlStr3);
				ResultSet rs3 = stmt3.executeQuery();
				rs3.close();
				stmt3.close();
				if (s.hasNextLine() == false) {
					select_login.setEnabled(true);
					System.out.println("End of Schema");
					break;
				}
			}
			havefile = true;
			UpdateMenu();
			setting();
		} else {
			return;
		}
	}
		
	////////////////////////////////////////////////////////////////
	

	public void CreateTable() throws SQLException {
		
		dropTable();
				
		String sqlStr = "CREATE TABLE customer(customer_name varchar2(14),customer_code varchar2(10),birthday varchar2(10),contact varchar2(10),grade varchar2(10),breakdown number(20), primary key(customer_name))";
		PreparedStatement stmt = DB.prepareStatement(sqlStr);
		ResultSet rs = stmt.executeQuery();
		rs.close();
		stmt.close();

		String sqlStr2 = "CREATE TABLE staff(staff_name varchar2(18),staff_code varchar2(10),staff_grade varchar2(20),sales number(20),primary key(staff_name))";
		PreparedStatement stmt2 = DB.prepareStatement(sqlStr2);
		ResultSet rs2 = stmt2.executeQuery();
		rs2.close();
		stmt2.close();

		String sqlStr3 = "CREATE TABLE menu(menu_name varchar2(30),price number(12),primary key(menu_name))";
		PreparedStatement stmt3 = DB.prepareStatement(sqlStr3);
		ResultSet rs3 = stmt3.executeQuery();
		rs3.close();
		stmt3.close();

		String sqlStr4 = "CREATE TABLE sales(dates date,sales number(20))";
		PreparedStatement stmt4 = DB.prepareStatement(sqlStr4);
		ResultSet rs4 = stmt4.executeQuery();
		rs4.close();
		stmt4.close();
		
		UpdateMenu();
	}
	
	
	public void dropTable(){
		try {
			String sqlStr = "DROP TABLE customer";
			PreparedStatement stmt = DB.prepareStatement(sqlStr);
			ResultSet rs = stmt.executeQuery();
			rs.close();
			stmt.close();
			String sqlStr2 = "DROP TABLE staff";
			PreparedStatement stmt2 = DB.prepareStatement(sqlStr2);
			ResultSet rs2 = stmt2.executeQuery();
			rs2.close();
			stmt2.close();
			String sqlStr3 = "DROP TABLE menu";
			PreparedStatement stmt3 = DB.prepareStatement(sqlStr3);
			ResultSet rs3 = stmt3.executeQuery();
			rs3.close();
			stmt3.close();
			String sqlStr4 = "DROP TABLE sales";
			PreparedStatement stmt4 = DB.prepareStatement(sqlStr4);
			ResultSet rs4 = stmt4.executeQuery();
			rs4.close();
			stmt4.close();			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void UpdateGrade(int _price, String temp) throws SQLException{
		String _grade;
		if(_price >= 1000000) _grade = "Gold";
		else if (_price >= 500000) _grade = "Silver";
		else if (_price >= 300000) _grade = "Bronze";
		else return;
		String sqlStr2 = "UPDATE customer SET grade ='" + _grade + "' WHERE customer_name='" + temp + "'";
		PreparedStatement stmt2 = DB.prepareStatement(sqlStr2);
		stmt2.executeUpdate();
		stmt2.close();			
	}
	
	public void connectDB(){
		try{
			Class.forName("oracle.jdbc.OracleDriver");
			DB = DriverManager.getConnection("jdbc:oracle:thin:"+"@localhost:1521:XE","system","system");
			System.out.println("�����ͺ��̽��� ����Ǿ����ϴ�.");
		} catch(SQLException e){
			e.printStackTrace();
			System.out.println("�����ͺ��̽� ���ῡ �����Ͽ����ϴ�.");
			System.out.println("SQLException: " +e);
		} catch(Exception e){
			System.out.println("Exception: " +e);
		}

	}

	private void UpdateMenu() {
		try {
			String sqlStr5 = "SELECT distinct menu_name from menu";
			PreparedStatement stmt5 = DB.prepareStatement(sqlStr5);
			ResultSet rs5 = stmt5.executeQuery();
			for (int i = 0; rs5.next(); i++) {
				menunames[i] = rs5.getString("menu_name");
				menuButton[i].setText(menunames[i]);
			}
			rs5.close();
			stmt5.close();
		} catch (SQLException e) {
			return;
		}
	}

	public void setting(){
		orderArea.setEnabled(isLogin);
		orderer_name.setEnabled(isLogin);
		tablelistCombo.setEnabled(isLogin);
		order_button.setEnabled(isLogin);
		pay_button.setEnabled(isLogin);
		cancel_button.setEnabled(isLogin);
		for (int i = 0; i < 20; i++) {
			menuButton[i].setEnabled(isLogin);
		}
		findcustomer.setEnabled(isLogin);
		findmenu.setEnabled(isLogin);
		findstaff.setEnabled(isLogin);
		select_login.setEnabled(havefile);
		select_open.setEnabled(!havefile);
		
		newstaff.setEnabled(isSupervisor);
		newcustomer.setEnabled(isSupervisor);
		newmenu.setEnabled(isSupervisor);
		saleddateCombo.setEnabled(isSupervisor);
	}
	

	public static void main(String[] args) {		
		MainPos mp = new MainPos();
		mp.setVisible(true);
	}
}
